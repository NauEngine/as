//
// Created by Alex Zelenshikov on 25.05.2024.
//

namespace as::benchmark
{
    double test_Cycle();
    double test_Array();
    double test_NQueen();
    double test_Life();
}